
export const environment = {

  firebase: {
      apiKey: "AIzaSyAvP0_pioJMpm36UoCaQiXkZkCGh0DfXXU",
      authDomain: "monosushi-286c8.firebaseapp.com",
      projectId: "monosushi-286c8",
      storageBucket: "monosushi-286c8.appspot.com",
      messagingSenderId: "903165471594",
      appId: "1:903165471594:web:c367d355182dd7bc71d313"
  },

  production: false,
  BACKEND_URL: "http://localhost:3000"
}; 
